import scrapy

class HuffPostScrapy(scrapy.Spider):
    name = 'citynews'
    start_urls = ['https://toronto.citynews.ca/category/national/']
    s = 'https://toronto.citynews.ca/category/national/page/'
    for i in range(2, 2000):
        start_urls.append(s + str(i) + '/')
    def parse(self, response):
        for newpap in response.css('div.col-lg-13.col-md-13.col-sm-13'):
            try:
                yield{
                    "article_link": newpap.css('a.title').attrib['href'],
                    "headline": newpap.css('a.title::text').get(),
                    "is_sarcastic": int(0),
                }
            except:
                continue
        
            '''next_page = 'https://fortune.com/' + response.css('div.paginationItem__wrapper--1F9Ak')[-1].css('a').attrib['href']
            if next_page is not None:
                yield response.follow(next_page, callback = self.parse)'''