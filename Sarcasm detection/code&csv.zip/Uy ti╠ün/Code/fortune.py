import scrapy

class FortuneScrapy(scrapy.Spider):
    name = 'fortune'
    start_urls = ['https://fortune.com/section/international/']

    def parse(self, response):
        for newpap in response.css('div.termArchiveContentListItem__title--14jcP'):
            try:
                yield{
                    "article_link": newpap.css('a')[1].attrib['href'],
                    "headline": newpap.css('div::text').get(),
                    "is_sarcastic": int(0),
                }
            except:
                continue
        
            next_page = 'https://fortune.com/' + response.css('div.paginationItem__wrapper--1F9Ak')[-1].css('a').attrib['href']
            if next_page is not None:
                yield response.follow(next_page, callback = self.parse)
            
