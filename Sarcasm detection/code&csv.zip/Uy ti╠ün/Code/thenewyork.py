import scrapy

class ArticleSpider(scrapy.Spider):
    name = 'thedaily'
    start_urls = ['https://www.nytimes.com/column/the-daily']

    def parse(self, response):
        for newpap in response.css('div.css-1l4spti'):
            try:
                yield{
                    "article_link": 'https://www.nytimes.com' + newpap.css('a').attrib['href'],
                    "headline": newpap.css('h2.css-1j9dxys.e1xfvim30::text').get(),
                    "is_sarcastic": int(1),
                }
            except:
                continue