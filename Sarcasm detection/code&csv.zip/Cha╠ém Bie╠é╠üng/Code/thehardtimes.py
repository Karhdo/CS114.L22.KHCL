import scrapy

class TheHardScrapy(scrapy.Spider):
    name = 'thehardtimes'
    start_urls = ['https://thehardtimes.net/']

    def parse(self, response):
        for newpap in response.css('div.post-header'):
            try:
                yield{
                    "article_link": newpap.css('a').attrib['href'],
                    "headline": newpap.css('a::text').get(),
                    "is_sarcastic": int(1),
                }
            except:
                continue
        
            next_page = response.css('a.next.page-numbers').attrib['href']
            if next_page is not None:
                yield response.follow(next_page, callback = self.parse)
            
