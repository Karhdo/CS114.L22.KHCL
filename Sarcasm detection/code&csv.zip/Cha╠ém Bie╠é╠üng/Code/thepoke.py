import scrapy

class PokeScrapy(scrapy.Spider):
    name = 'poke'
    start_urls = ['https://www.thepoke.co.uk/']

    def parse(self, response):
        for newpap in response.css('article.boxgrid'):
            try:
                yield{
                    "article_link": newpap.css('a').attrib['href'],
                    "headline": newpap.css('p::text').get(),
                    "is_sarcastic": int(1),
                }
            except:
                continue
        
            next_page = response.css('div.prev').css('a').attrib['href']
            if next_page is not None:
                yield response.follow(next_page, callback = self.parse)
            
